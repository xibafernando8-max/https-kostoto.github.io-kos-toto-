KOSTOTO — Panel Transaksi & Bonus CB

CARA PAKAI
1. Ekstrak folder/ZIP ini.
2. Buka index.html menggunakan browser modern (Chrome, Edge, Firefox).
3. Masukkan User ID, info, status, jumlah, dan persentase CB.
4. Klik Simpan Transaksi. Data tersimpan di browser/perangkat yang sama.
5. Gunakan Ekspor CSV untuk membuat cadangan data.

ATURAN PERHITUNGAN
- Status Deposit: bonus CB = jumlah × persentase CB.
- Status Bonus CB: jumlah yang dimasukkan dicatat langsung sebagai bonus CB.
- Status Withdraw: bonus CB = 0.

CATATAN
- Ini aplikasi web lokal tanpa server/login; data tidak otomatis tersinkron ke perangkat lain.
- Hapus data browser dapat menghapus catatan lokal. Ekspor CSV untuk backup.
- Background menggunakan gambar yang disertakan dalam paket.
